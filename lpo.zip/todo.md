# LPO Manager - Implementation TODO

## Phase 1: Database Schema & Core Models
- [x] Define LPO table schema (id, userId, lpoNumber, supplierName, deliveryTo, deliveryDate, etc.)
- [x] Define LPOItem table schema (id, lpoId, itemNo, description, unitPrice, quantity, total)
- [x] Add school header fields (schoolName, schoolAddress, schoolLogo)
- [x] Add status tracking field (draft, submitted, approved, rejected)
- [x] Generate and apply database migrations

## Phase 2: Authentication
- [x] Implement user registration endpoint with validation
- [x] Implement user login endpoint with password hashing
- [x] Set up protected routes and middleware
- [x] Create login/register pages with form validation
- [x] Test authentication flow end-to-end

## Phase 3: LPO Creation
- [x] Build LPO creation form with supplier details
- [x] Implement line items form (add/remove items dynamically)
- [x] Add editable school name and address fields
- [x] Implement server-side validation for LPO data
- [x] Create tRPC procedure for LPO creation
- [x] Test LPO creation with multiple line items

## Phase 4: LPO Dashboard & Search
- [x] Create dashboard page listing user's LPOs
- [x] Implement search by LPO number and supplier name
- [x] Add pagination or infinite scroll
- [x] Display LPO status and key details in list
- [x] Test search and filtering functionality

## Phase 5: LPO Detail View
- [x] Create detail page showing full LPO information
- [x] Display all line items in a table
- [x] Implement status update functionality
- [x] Implement notes update functionality
- [ ] Add delete LPO capability
- [x] Test detail view and updates

## Phase 6: A4 PDF Generation
- [x] Upload and embed school logo (32mm × 42mm)
- [x] Create Python fpdf2 script for A4 PDF generation
- [x] Implement 15-row fixed table layout
- [x] Add editable school name and address to PDF header
- [x] Ensure strict A4 portrait dimensions (210mm × 297mm)
- [x] Test PDF generation with sample data

## Phase 7: PDF Download Integration
- [x] Create Express endpoint for PDF download
- [x] Integrate PDF endpoint with frontend
- [x] Implement download button on LPO detail page
- [x] Test PDF download and file integrity
- [x] Verify PDF dimensions and logo placement

## Phase 8: Testing & Deployment
- [x] Write vitest tests for authentication
- [x] Write vitest tests for LPO creation
- [x] Write vitest tests for PDF generation
- [x] Perform end-to-end testing (register → create → download PDF)
- [x] Create final checkpoint for deployment
- [x] Provide permanent live link to user

## Additional Tasks
- [ ] Set up proper error handling and user feedback (toast notifications)
- [ ] Ensure responsive design for mobile and desktop
- [ ] Add loading states and spinners
- [ ] Implement empty states for dashboard
- [ ] Add confirmation dialogs for destructive actions
