import { eq, and, or, like, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, lpos, lpoItems, InsertLPO, InsertLPOItem } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createLPO(data: InsertLPO): Promise<{ id: number }> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(lpos).values(data);
  const insertedId = (result as any).insertId;
  if (!insertedId) throw new Error("Failed to create LPO");
  return { id: insertedId };
}

export async function getLPOById(id: number) {
  const db = await getDb();
  if (!db) return null;
  
  const result = await db.select().from(lpos).where(eq(lpos.id, id)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getLPOsByUserId(userId: number, limit = 50, offset = 0, search?: string) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select().from(lpos).where(eq(lpos.userId, userId));
  
  if (search) {
    const { or, like } = await import("drizzle-orm");
    query = db.select().from(lpos).where(
      and(
        eq(lpos.userId, userId),
        or(
          like(lpos.lpoNumber, `%${search}%`),
          like(lpos.supplierName, `%${search}%`)
        )
      )
    );
  }
  
  return await query.limit(limit).offset(offset).orderBy(desc(lpos.createdAt));
}

export async function updateLPO(id: number, data: Partial<InsertLPO>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(lpos).set(data).where(eq(lpos.id, id));
}

export async function deleteLPO(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(lpos).where(eq(lpos.id, id));
}

export async function createLPOItem(data: InsertLPOItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(lpoItems).values(data);
  return result;
}

export async function getLPOItemsByLPOId(lpoId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(lpoItems).where(eq(lpoItems.lpoId, lpoId)).orderBy(lpoItems.itemNo);
}

export async function deleteLPOItem(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(lpoItems).where(eq(lpoItems.id, id));
}

export async function deleteLPOItemsByLPOId(lpoId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(lpoItems).where(eq(lpoItems.lpoId, lpoId));
}
