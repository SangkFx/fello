import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";
import * as authUtils from "./auth-utils";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    
    register: publicProcedure
      .input(
        z.object({
          username: z.string().min(3, "Username must be at least 3 characters"),
          email: z.string().email("Invalid email address"),
          name: z.string().min(1, "Name is required"),
          password: z.string().min(6, "Password must be at least 6 characters"),
        })
      )
      .mutation(async ({ input }) => {
        const existingUser = await authUtils.getUserByUsername(input.username);
        if (existingUser) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Username already exists" });
        }

        const existingEmail = await authUtils.getUserByEmail(input.email);
        if (existingEmail) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Email already exists" });
        }

        await authUtils.createLocalUser(input.username, input.email, input.name, input.password);
        return { success: true };
      }),

    login: publicProcedure
      .input(
        z.object({
          username: z.string().min(1, "Username is required"),
          password: z.string().min(1, "Password is required"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const user = await authUtils.validateUserCredentials(input.username, input.password);
        if (!user) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid username or password" });
        }

        const sessionToken = Buffer.from(JSON.stringify({ userId: user.id, username: user.username })).toString("base64");
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.setHeader(
          "Set-Cookie",
          `${COOKIE_NAME}=${sessionToken}; Path=/; HttpOnly; Secure; SameSite=None; Max-Age=31536000`
        );

        return {
          success: true,
          user: {
            id: user.id,
            username: user.username,
            name: user.name,
            email: user.email,
            role: user.role,
          },
        };
      }),

    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  lpo: router({
    create: protectedProcedure
      .input(
        z.object({
          lpoNumber: z.string().min(1, "LPO Number is required"),
          supplierName: z.string().min(1, "Supplier name is required"),
          supplierId: z.string().optional(),
          deliveryTo: z.string().min(1, "Delivery location is required"),
          deliveryDate: z.date(),
          invoiceSubmitTo: z.string().optional(),
          tenderRefNo: z.string().optional(),
          quotationRefNo: z.string().optional(),
          contractRefNo: z.string().optional(),
          refDate: z.date().optional(),
          notes: z.string().optional(),
          schoolName: z.string().optional(),
          schoolAddress: z.string().optional(),
          schoolLogo: z.string().optional(),
          items: z.array(
            z.object({
              itemNo: z.number(),
              description: z.string().min(1),
              unitPrice: z.number().min(0),
              quantity: z.string().min(1),
              total: z.number().min(0),
            })
          ).min(1, "At least one item is required"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const { items, ...lpoData } = input;
        try {
          const result = await db.createLPO({
            ...lpoData,
            userId: ctx.user.id,
            grandTotal: items.reduce((sum, item) => sum + item.total, 0),
          });
          
          for (const item of items) {
            await db.createLPOItem({
              ...item,
              lpoId: result.id,
            });
          }
          
          return { success: true, lpoId: result.id };
        } catch (error) {
          console.error("[LPO Create Error]", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: error instanceof Error ? error.message : "Failed to create LPO",
          });
        }
      }),

    list: protectedProcedure
      .input(
        z.object({
          limit: z.number().default(50),
          offset: z.number().default(0),
          search: z.string().optional(),
        })
      )
      .query(async ({ ctx, input }) => {
        return db.getLPOsByUserId(ctx.user.id, input.limit, input.offset, input.search);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const lpo = await db.getLPOById(input.id);
        if (!lpo || lpo.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND", message: "LPO not found" });
        }
        const items = await db.getLPOItemsByLPOId(input.id);
        return { lpo, items };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          data: z.object({
            status: z.enum(["draft", "submitted", "approved", "rejected"]).optional(),
            notes: z.string().optional(),
          }),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const lpo = await db.getLPOById(input.id);
        if (!lpo || lpo.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND", message: "LPO not found" });
        }
        await db.updateLPO(input.id, input.data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const lpo = await db.getLPOById(input.id);
        if (!lpo || lpo.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND", message: "LPO not found" });
        }
        await db.deleteLPOItemsByLPOId(input.id);
        await db.deleteLPO(input.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
