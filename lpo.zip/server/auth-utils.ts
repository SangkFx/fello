import bcrypt from "bcryptjs";
import * as db from "./db";
import { InsertUser } from "../drizzle/schema";

const SALT_ROUNDS = 10;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function createLocalUser(
  username: string,
  email: string,
  name: string,
  password: string
) {
  const passwordHash = await hashPassword(password);
  
  const user: InsertUser = {
    username,
    email,
    name,
    passwordHash,
    loginMethod: "local",
    openId: `local_${username}_${Date.now()}`,
  };

  await db.upsertUser(user);
  const createdUser = await db.getUserByUsername(username);
  return createdUser;
}

export async function validateUserCredentials(username: string, password: string) {
  const user = await db.getUserByUsername(username);
  if (!user || !user.passwordHash) {
    return null;
  }

  const isValid = await verifyPassword(password, user.passwordHash);
  if (!isValid) {
    return null;
  }

  return user;
}

export async function getUserByUsername(username: string) {
  return db.getUserByUsername(username);
}

export async function getUserByEmail(email: string) {
  return db.getUserByEmail(email);
}
