#!/usr/bin/env python3
"""
Server-side A4 PDF generation for LPO documents using fpdf2.
Generates a professional LPO with school logo at top corners (32mm x 42mm).
"""

import sys
import json
import base64
from io import BytesIO
from fpdf import FPDF
from datetime import datetime

def generate_lpo_pdf(lpo_data: dict, items_data: list, logo_base64: str = None) -> bytes:
    """
    Generate an A4 portrait PDF for an LPO document.
    
    Args:
        lpo_data: Dictionary containing LPO header information
        items_data: List of line item dictionaries
        logo_base64: Base64 encoded logo image
    
    Returns:
        PDF file as bytes
    """
    
    # Create PDF with A4 portrait orientation (210mm x 297mm)
    pdf = FPDF(orientation='P', unit='mm', format='A4')
    pdf.add_page()
    
    # Set default font
    pdf.set_font('Arial', '', 10)
    
    # Top margin
    y_pos = 10
    
    # Add logos at top corners (32mm width x 42mm height)
    if logo_base64:
        try:
            logo_bytes = base64.b64decode(logo_base64)
            logo_file = BytesIO(logo_bytes)
            # Left logo
            pdf.image(logo_file, x=10, y=y_pos, w=32, h=42)
            # Right logo
            logo_file.seek(0)
            pdf.image(logo_file, x=210 - 10 - 32, y=y_pos, w=32, h=42)
        except Exception as e:
            print(f"Warning: Could not add logo: {e}", file=sys.stderr)
    
    # School header (centered)
    y_pos = 15
    pdf.set_font('Arial', 'B', 16)
    pdf.set_xy(10, y_pos)
    pdf.cell(190, 8, lpo_data.get('schoolName', 'CHANIA BOYS HIGH SCHOOL'), 0, 1, 'C')
    
    pdf.set_font('Arial', '', 10)
    pdf.set_xy(10, y_pos + 8)
    pdf.cell(190, 6, lpo_data.get('schoolAddress', 'P.O. Box 45 - 01000, Thika, Kenya'), 0, 1, 'C')
    
    # LPO Title and Number
    y_pos += 20
    pdf.set_font('Arial', 'B', 12)
    pdf.set_xy(10, y_pos)
    pdf.cell(150, 8, 'LOCAL PURCHASE ORDER', 0, 0)
    pdf.set_font('Arial', 'B', 14)
    pdf.set_xy(160, y_pos)
    pdf.cell(30, 8, f"No.{lpo_data.get('lpoNumber', '')}", 0, 1)
    
    # Horizontal line
    y_pos += 10
    pdf.set_xy(10, y_pos)
    pdf.cell(190, 0, '', 1, 1)
    
    # School/Institution line
    y_pos += 3
    pdf.set_font('Arial', '', 9)
    pdf.set_xy(10, y_pos)
    pdf.cell(20, 6, 'School / Institution:', 0, 0)
    pdf.set_xy(50, y_pos)
    pdf.cell(150, 6, lpo_data.get('schoolName', 'Chania Boys High School'), 0, 1)
    
    # Merchant warning line
    y_pos += 6
    pdf.set_font('Arial', '', 8)
    pdf.set_xy(10, y_pos)
    pdf.cell(190, 5, 'Merchants are warned not to supply goods against this order unless it is properly completed)', 0, 1)
    
    # Supplier details
    y_pos += 6
    pdf.set_font('Arial', 'B', 9)
    pdf.set_xy(10, y_pos)
    pdf.cell(20, 5, 'TO:', 0, 0)
    pdf.set_font('Arial', '', 9)
    pdf.set_xy(15, y_pos)
    pdf.cell(185, 5, lpo_data.get('supplierName', ''), 0, 1)
    
    # ID Number
    y_pos += 5
    pdf.set_font('Arial', 'B', 9)
    pdf.set_xy(10, y_pos)
    pdf.cell(20, 5, 'ID NUMBER:', 0, 0)
    pdf.set_font('Arial', '', 9)
    pdf.set_xy(50, y_pos)
    pdf.cell(150, 5, lpo_data.get('supplierId', ''), 0, 1)
    
    # Tender/Quotation/Contract details
    y_pos += 6
    pdf.set_font('Arial', 'B', 8)
    pdf.set_xy(10, y_pos)
    pdf.cell(50, 4, f"Tender/Contract/Quotation Ref. No. {lpo_data.get('tenderRefNo', '')}", 0, 0)
    pdf.set_font('Arial', '', 8)
    pdf.set_xy(120, y_pos)
    pdf.cell(80, 4, f"Date {lpo_data.get('refDate', '')}", 0, 1)
    
    # Delivery information
    y_pos += 5
    pdf.set_font('Arial', '', 8)
    pdf.set_xy(10, y_pos)
    pdf.cell(190, 4, '(these particulars must be quoted on all invoices and statements)', 0, 1)
    
    y_pos += 4
    pdf.set_font('Arial', '', 9)
    pdf.set_xy(10, y_pos)
    pdf.cell(30, 5, 'Please deliver the following goods to:', 0, 0)
    pdf.set_font('Arial', 'B', 9)
    pdf.set_xy(50, y_pos)
    pdf.cell(150, 5, lpo_data.get('deliveryTo', 'Chania Boys High School'), 0, 1)
    
    y_pos += 5
    pdf.set_font('Arial', '', 8)
    pdf.set_xy(10, y_pos)
    pdf.cell(50, 4, f"on or before {lpo_data.get('deliveryDate', '')}", 0, 0)
    pdf.set_font('Arial', 'B', 8)
    pdf.set_xy(120, y_pos)
    pdf.cell(80, 4, 'Finance Department', 0, 1)
    
    y_pos += 4
    pdf.set_font('Arial', '', 8)
    pdf.set_xy(10, y_pos)
    pdf.cell(190, 4, 'and submit invoices without delay to', 0, 1)
    
    # Line items table header
    y_pos += 6
    pdf.set_font('Arial', 'B', 9)
    pdf.set_xy(10, y_pos)
    pdf.cell(10, 6, 'Item No.', 1, 0, 'C')
    pdf.cell(70, 6, 'DESCRIPTION OF GOODS', 1, 0, 'C')
    pdf.cell(30, 6, 'UNIT', 1, 0, 'C')
    pdf.cell(20, 6, 'QUANTITY', 1, 0, 'C')
    pdf.cell(30, 6, 'PRICE KShs.', 1, 0, 'C')
    pdf.cell(20, 6, 'CTS.', 1, 1, 'C')
    
    # Line items (15 rows total for fixed layout)
    y_pos += 6
    row_height = 8
    total_items_height = 15 * row_height  # 15 rows x 8mm each
    
    pdf.set_font('Arial', '', 8)
    
    for i in range(15):
        if i < len(items_data):
            item = items_data[i]
            pdf.set_xy(10, y_pos)
            pdf.cell(10, row_height, str(item.get('itemNo', i + 1)), 1, 0, 'C')
            pdf.cell(70, row_height, str(item.get('description', '')), 1, 0)
            pdf.cell(30, row_height, str(item.get('unit', '')), 1, 0, 'C')
            pdf.cell(20, row_height, str(item.get('quantity', '')), 1, 0, 'C')
            price = item.get('unitPrice', 0)
            pdf.cell(30, row_height, f"{price:,.0f}", 1, 0, 'R')
            pdf.cell(20, row_height, '00', 1, 1, 'C')
        else:
            # Empty row
            pdf.set_xy(10, y_pos)
            pdf.cell(10, row_height, '', 1, 0)
            pdf.cell(70, row_height, '', 1, 0)
            pdf.cell(30, row_height, '', 1, 0)
            pdf.cell(20, row_height, '', 1, 0)
            pdf.cell(30, row_height, '', 1, 0)
            pdf.cell(20, row_height, '', 1, 1)
        
        y_pos += row_height
    
    # Total row
    pdf.set_font('Arial', 'B', 9)
    pdf.set_xy(10, y_pos)
    pdf.cell(130, 8, 'TOTAL', 1, 0, 'R')
    grand_total = lpo_data.get('grandTotal', 0)
    pdf.cell(30, 8, f"{grand_total:,.0f}", 1, 0, 'R')
    pdf.cell(20, 8, '00', 1, 1, 'C')
    
    # Footer information
    y_pos += 12
    pdf.set_font('Arial', '', 8)
    pdf.set_xy(10, y_pos)
    pdf.cell(50, 4, 'ORIGINAL:- To Suppliers', 0, 1)
    pdf.set_xy(10, y_pos + 4)
    pdf.cell(50, 4, 'DUPLICATE:- To be filed with PV', 0, 1)
    pdf.set_xy(10, y_pos + 8)
    pdf.cell(50, 4, 'TRIPLICATE:- To remain in Book', 0, 1)
    
    # Signature section
    y_pos += 16
    pdf.set_font('Arial', '', 8)
    pdf.set_xy(120, y_pos)
    pdf.cell(80, 4, 'Vote Head Charge:________________', 0, 1)
    pdf.set_xy(120, y_pos + 6)
    pdf.cell(80, 4, 'Signature:_____________________', 0, 1)
    pdf.set_xy(120, y_pos + 12)
    pdf.cell(80, 4, 'Designation:___________________', 0, 1)
    pdf.set_xy(120, y_pos + 18)
    pdf.cell(80, 4, 'Date:_________________________', 0, 1)
    
    # Return PDF as bytes
    return pdf.output()


if __name__ == '__main__':
    try:
        # Read input from stdin
        input_data = json.loads(sys.stdin.read())
        
        lpo_data = input_data.get('lpo', {})
        items_data = input_data.get('items', [])
        logo_base64 = input_data.get('logo', None)
        
        # Generate PDF
        pdf_bytes = generate_lpo_pdf(lpo_data, items_data, logo_base64)
        
        # Write PDF to stdout as binary
        sys.stdout.buffer.write(pdf_bytes)
        
    except Exception as e:
        print(f"Error generating PDF: {e}", file=sys.stderr)
        sys.exit(1)
