import { Router, Request, Response } from 'express';
import { spawn } from 'child_process';
import { getDb } from './db';
import { lpos, lpoItems } from '../drizzle/schema';
import { eq } from 'drizzle-orm';

const router = Router();

const LOGO_BASE64 = process.env.SCHOOL_LOGO_BASE64 || '';

router.get('/lpo/:id/pdf', async (req, res) => {
  try {
    const lpoId = parseInt(req.params.id);
    
    if (isNaN(lpoId)) {
      return res.status(400).json({ error: 'Invalid LPO ID' });
    }

    const db = await getDb();
    if (!db) {
      return res.status(500).json({ error: 'Database not available' });
    }

    // Fetch LPO data
    const lpoResult = await db.select().from(lpos).where(eq(lpos.id, lpoId)).limit(1);
    if (lpoResult.length === 0) {
      return res.status(404).json({ error: 'LPO not found' });
    }

    const lpoData = lpoResult[0];

    // Fetch line items
    const itemsResult = await db.select().from(lpoItems).where(eq(lpoItems.lpoId, lpoId));

    // Prepare data for Python script
    const pdfData = {
      lpo: {
        lpoNumber: lpoData.lpoNumber,
        supplierName: lpoData.supplierName,
        supplierId: lpoData.supplierId || '',
        deliveryTo: lpoData.deliveryTo,
        deliveryDate: lpoData.deliveryDate ? new Date(lpoData.deliveryDate).toLocaleDateString() : '',
        schoolName: lpoData.schoolName || 'Chania Boys High School',
        schoolAddress: lpoData.schoolAddress || 'P.O. Box 45 - 01000, Thika, Kenya',
        tenderRefNo: lpoData.tenderRefNo || '',
        quotationRefNo: lpoData.quotationRefNo || '',
        contractRefNo: lpoData.contractRefNo || '',
        refDate: lpoData.refDate ? new Date(lpoData.refDate).toLocaleDateString() : '',
        grandTotal: lpoData.grandTotal || 0,
      },
      items: itemsResult.map(item => ({
        itemNo: item.itemNo,
        description: item.description,
        unit: '',
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        total: item.total,
      })),
      logo: LOGO_BASE64,
    };

    // Call Python script to generate PDF
    const pythonProcess = spawn('python3', [
      `${process.cwd()}/server/generate_pdf.py`,
    ]);

    let pdfBuffer = Buffer.alloc(0);
    let errorOutput = '';

    pythonProcess.stdout.on('data', (data) => {
      pdfBuffer = Buffer.concat([pdfBuffer, data]);
    });

    pythonProcess.stderr.on('data', (data) => {
      errorOutput += data.toString();
    });

    pythonProcess.on('close', (code) => {
      if (code !== 0) {
        console.error('PDF generation error:', errorOutput);
        return res.status(500).json({ error: 'Failed to generate PDF' });
      }

      // Send PDF to client
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="LPO_${lpoData.lpoNumber}.pdf"`);
      res.send(pdfBuffer);
    });

    // Send data to Python script
    pythonProcess.stdin.write(JSON.stringify(pdfData));
    pythonProcess.stdin.end();

  } catch (error) {
    console.error('PDF endpoint error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
