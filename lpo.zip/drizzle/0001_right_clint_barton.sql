CREATE TABLE `lpoItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lpoId` int NOT NULL,
	`itemNo` int NOT NULL,
	`description` text NOT NULL,
	`unitPrice` int NOT NULL,
	`quantity` varchar(64) NOT NULL,
	`total` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lpoItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lpos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`lpoNumber` varchar(64) NOT NULL,
	`supplierName` varchar(255) NOT NULL,
	`supplierId` varchar(64),
	`deliveryTo` varchar(255) NOT NULL,
	`deliveryDate` timestamp NOT NULL,
	`invoiceSubmitTo` varchar(255),
	`tenderRefNo` varchar(64),
	`quotationRefNo` varchar(64),
	`contractRefNo` varchar(64),
	`refDate` timestamp,
	`grandTotal` int NOT NULL DEFAULT 0,
	`status` enum('draft','submitted','approved','rejected') NOT NULL DEFAULT 'draft',
	`notes` text,
	`schoolName` varchar(255),
	`schoolAddress` text,
	`schoolLogo` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lpos_id` PRIMARY KEY(`id`),
	CONSTRAINT `lpos_lpoNumber_unique` UNIQUE(`lpoNumber`)
);
