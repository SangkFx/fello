import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  username: varchar("username", { length: 100 }).unique(),
  passwordHash: text("passwordHash"),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const lpos = mysqlTable("lpos", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  lpoNumber: varchar("lpoNumber", { length: 64 }).notNull().unique(),
  supplierName: varchar("supplierName", { length: 255 }).notNull(),
  supplierId: varchar("supplierId", { length: 64 }),
  deliveryTo: varchar("deliveryTo", { length: 255 }).notNull(),
  deliveryDate: timestamp("deliveryDate").notNull(),
  invoiceSubmitTo: varchar("invoiceSubmitTo", { length: 255 }),
  tenderRefNo: varchar("tenderRefNo", { length: 64 }),
  quotationRefNo: varchar("quotationRefNo", { length: 64 }),
  contractRefNo: varchar("contractRefNo", { length: 64 }),
  refDate: timestamp("refDate"),
  grandTotal: int("grandTotal").default(0).notNull(),
  status: mysqlEnum("status", ["draft", "submitted", "approved", "rejected"]).default("draft").notNull(),
  notes: text("notes"),
  schoolName: varchar("schoolName", { length: 255 }),
  schoolAddress: text("schoolAddress"),
  schoolLogo: text("schoolLogo"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LPO = typeof lpos.$inferSelect;
export type InsertLPO = typeof lpos.$inferInsert;

export const lpoItems = mysqlTable("lpoItems", {
  id: int("id").autoincrement().primaryKey(),
  lpoId: int("lpoId").notNull(),
  itemNo: int("itemNo").notNull(),
  description: text("description").notNull(),
  unitPrice: int("unitPrice").notNull(),
  quantity: varchar("quantity", { length: 64 }).notNull(),
  total: int("total").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type LPOItem = typeof lpoItems.$inferSelect;
export type InsertLPOItem = typeof lpoItems.$inferInsert;
