import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");

  const { data: lpos, isLoading } = trpc.lpo.list.useQuery({
    limit: 50,
    offset: 0,
    search: search || undefined,
  });

  const handleViewLPO = (id: number) => {
    setLocation(`/lpo/${id}`);
  };

  const handleCreateLPO = () => {
    setLocation("/create-lpo");
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">LPO Dashboard</h1>
            <p className="text-muted-foreground">Manage your Local Purchase Orders</p>
          </div>
          <Button onClick={handleCreateLPO} size="lg">
            Create New LPO
          </Button>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <Input
              placeholder="Search by LPO number or supplier name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full"
            />
          </CardContent>
        </Card>

        {/* LPO List */}
        <Card>
          <CardHeader>
            <CardTitle>Local Purchase Orders</CardTitle>
            <CardDescription>
              {isLoading ? "Loading..." : `${lpos?.length || 0} LPO(s) found`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="animate-spin mr-2" />
                Loading LPOs...
              </div>
            ) : lpos && lpos.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">LPO No.</th>
                      <th className="text-left py-3 px-4">Supplier</th>
                      <th className="text-left py-3 px-4">Delivery To</th>
                      <th className="text-right py-3 px-4">Grand Total</th>
                      <th className="text-center py-3 px-4">Status</th>
                      <th className="text-center py-3 px-4">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {lpos.map((lpo) => (
                      <tr key={lpo.id} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-4 font-medium">{lpo.lpoNumber}</td>
                        <td className="py-3 px-4">{lpo.supplierName}</td>
                        <td className="py-3 px-4">{lpo.deliveryTo}</td>
                        <td className="py-3 px-4 text-right">{lpo.grandTotal.toLocaleString()}</td>
                        <td className="py-3 px-4 text-center">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            lpo.status === "draft" ? "bg-gray-200 text-gray-800" :
                            lpo.status === "submitted" ? "bg-blue-200 text-blue-800" :
                            lpo.status === "approved" ? "bg-green-200 text-green-800" :
                            "bg-red-200 text-red-800"
                          }`}>
                            {lpo.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewLPO(lpo.id)}
                          >
                            View
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">No LPOs found</p>
                <Button onClick={handleCreateLPO} variant="outline">
                  Create your first LPO
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
