import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface LineItem {
  itemNo: number;
  description: string;
  unitPrice: number;
  quantity: string;
  total: number;
}

export default function CreateLPO() {
  const [, setLocation] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [items, setItems] = useState<LineItem[]>([
    { itemNo: 1, description: "", unitPrice: 0, quantity: "", total: 0 },
  ]);

  const [formData, setFormData] = useState({
    lpoNumber: "",
    supplierName: "",
    supplierId: "",
    deliveryTo: "",
    deliveryDate: new Date().toISOString().split("T")[0],
    invoiceSubmitTo: "",
    tenderRefNo: "",
    quotationRefNo: "",
    contractRefNo: "",
    refDate: "",
    notes: "",
    schoolName: "Chania Boys High School",
    schoolAddress: "P.O. Box 45 - 01000, Thika, Kenya",
    schoolLogo: "",
  });

  const createLPOMutation = trpc.lpo.create.useMutation();

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleItemChange = (index: number, field: keyof LineItem, value: any) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    
    if (field === "unitPrice" || field === "quantity") {
      const unitPrice = field === "unitPrice" ? value : newItems[index].unitPrice;
      const qty = field === "quantity" ? value : newItems[index].quantity;
      newItems[index].total = Math.round(unitPrice * (parseInt(qty) || 0));
    }
    
    setItems(newItems);
  };

  const addItem = () => {
    setItems([...items, {
      itemNo: items.length + 1,
      description: "",
      unitPrice: 0,
      quantity: "",
      total: 0,
    }]);
  };

  const removeItem = (index: number) => {
    if (items.length > 1) {
      setItems(items.filter((_, i) => i !== index));
    } else {
      toast.error("At least one item is required");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.lpoNumber || !formData.supplierName || !formData.deliveryTo) {
      toast.error("Please fill in all required fields");
      return;
    }

    if (items.some(item => !item.description || item.unitPrice <= 0 || !item.quantity)) {
      toast.error("Please fill in all item details");
      return;
    }

    setIsLoading(true);
    try {
      await createLPOMutation.mutateAsync({
        ...formData,
        deliveryDate: new Date(formData.deliveryDate),
        refDate: formData.refDate ? new Date(formData.refDate) : undefined,
        items: items.map(item => ({
          itemNo: item.itemNo,
          description: item.description,
          unitPrice: Math.round(item.unitPrice),
          quantity: item.quantity,
          total: item.total,
        })),
      });
      toast.success("LPO created successfully");
      setLocation("/dashboard");
    } catch (error: any) {
      toast.error(error.message || "Failed to create LPO");
    } finally {
      setIsLoading(false);
    }
  };

  const grandTotal = items.reduce((sum, item) => sum + item.total, 0);

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Create Local Purchase Order</CardTitle>
            <CardDescription>Fill in the LPO details and line items</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* School Information */}
              <div className="border-b pb-4">
                <h3 className="text-lg font-semibold mb-4">School Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">School Name</label>
                    <Input
                      name="schoolName"
                      value={formData.schoolName}
                      onChange={handleFormChange}
                      disabled={isLoading}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">School Address</label>
                    <Input
                      name="schoolAddress"
                      value={formData.schoolAddress}
                      onChange={handleFormChange}
                      disabled={isLoading}
                    />
                  </div>
                </div>
              </div>

              {/* LPO Header */}
              <div className="border-b pb-4">
                <h3 className="text-lg font-semibold mb-4">LPO Details</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">LPO Number *</label>
                    <Input
                      name="lpoNumber"
                      value={formData.lpoNumber}
                      onChange={handleFormChange}
                      placeholder="e.g., 2217"
                      disabled={isLoading}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Supplier Name *</label>
                    <Input
                      name="supplierName"
                      value={formData.supplierName}
                      onChange={handleFormChange}
                      placeholder="e.g., JOSEPH NGOWA KATANA"
                      disabled={isLoading}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Delivery To *</label>
                    <Input
                      name="deliveryTo"
                      value={formData.deliveryTo}
                      onChange={handleFormChange}
                      placeholder="e.g., Chania Boys High School"
                      disabled={isLoading}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Delivery Date</label>
                    <Input
                      type="date"
                      name="deliveryDate"
                      value={formData.deliveryDate}
                      onChange={handleFormChange}
                      disabled={isLoading}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Tender Ref. No.</label>
                    <Input
                      name="tenderRefNo"
                      value={formData.tenderRefNo}
                      onChange={handleFormChange}
                      disabled={isLoading}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Quotation Ref. No.</label>
                    <Input
                      name="quotationRefNo"
                      value={formData.quotationRefNo}
                      onChange={handleFormChange}
                      disabled={isLoading}
                    />
                  </div>
                </div>
              </div>

              {/* Line Items */}
              <div className="border-b pb-4">
                <h3 className="text-lg font-semibold mb-4">Line Items</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2">Item No.</th>
                        <th className="text-left py-2">Description</th>
                        <th className="text-right py-2">Unit Price</th>
                        <th className="text-right py-2">Quantity</th>
                        <th className="text-right py-2">Total</th>
                        <th className="text-center py-2">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {items.map((item, index) => (
                        <tr key={index} className="border-b">
                          <td className="py-2">{item.itemNo}</td>
                          <td className="py-2">
                            <Input
                              value={item.description}
                              onChange={(e) => handleItemChange(index, "description", e.target.value)}
                              placeholder="Description"
                              disabled={isLoading}
                              className="text-xs"
                            />
                          </td>
                          <td className="py-2">
                            <Input
                              type="number"
                              value={item.unitPrice}
                              onChange={(e) => handleItemChange(index, "unitPrice", parseFloat(e.target.value) || 0)}
                              placeholder="0.00"
                              disabled={isLoading}
                              className="text-xs text-right"
                            />
                          </td>
                          <td className="py-2">
                            <Input
                              value={item.quantity}
                              onChange={(e) => handleItemChange(index, "quantity", e.target.value)}
                              placeholder="Qty"
                              disabled={isLoading}
                              className="text-xs text-right"
                            />
                          </td>
                          <td className="py-2 text-right">{item.total.toLocaleString()}</td>
                          <td className="py-2 text-center">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removeItem(index)}
                              disabled={isLoading}
                            >
                              Remove
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={addItem}
                  disabled={isLoading}
                  className="mt-4"
                >
                  Add Item
                </Button>
              </div>

              {/* Grand Total */}
              <div className="flex justify-end">
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Grand Total</p>
                  <p className="text-2xl font-bold">{grandTotal.toLocaleString()}</p>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="text-sm font-medium">Notes</label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleFormChange}
                  placeholder="Additional notes (optional)"
                  disabled={isLoading}
                  className="w-full p-2 border rounded text-sm"
                  rows={3}
                />
              </div>

              {/* Submit Button */}
              <div className="flex gap-4">
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="flex-1"
                >
                  {isLoading ? "Creating..." : "Create LPO"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation("/dashboard")}
                  disabled={isLoading}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
