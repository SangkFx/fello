import { useState } from "react";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Loader2, Download } from "lucide-react";

export default function LPODetail() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/lpo/:id");
  const lpoId = params?.id ? parseInt(params.id) : 0;

  const [status, setStatus] = useState("");
  const [notes, setNotes] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);
  const [isDownloadingPDF, setIsDownloadingPDF] = useState(false);

  const { data: lpoData, isLoading } = trpc.lpo.getById.useQuery({ id: lpoId });
  const updateMutation = trpc.lpo.update.useMutation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin mr-2" />
        Loading LPO...
      </div>
    );
  }

  if (!lpoData) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <p className="text-lg text-muted-foreground mb-4">LPO not found</p>
        <Button onClick={() => setLocation("/dashboard")}>Back to Dashboard</Button>
      </div>
    );
  }

  const { lpo, items } = lpoData;

  const handleUpdateStatus = async () => {
    if (!status) {
      toast.error("Please select a status");
      return;
    }

    setIsUpdating(true);
    try {
      await updateMutation.mutateAsync({
        id: lpoId,
        data: { status: status as any, notes },
      });
      toast.success("LPO updated successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to update LPO");
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDownloadPDF = async () => {
    setIsDownloadingPDF(true);
    try {
      // Call the PDF download endpoint
      const response = await fetch(`/api/lpo/${lpoId}/pdf`, {
        method: "GET",
      });

      if (!response.ok) {
        throw new Error("Failed to download PDF");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `LPO_${lpo.lpoNumber}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast.success("PDF downloaded successfully");
    } catch (error: any) {
      toast.error(error.message || "Failed to download PDF");
    } finally {
      setIsDownloadingPDF(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">LPO #{lpo.lpoNumber}</h1>
            <p className="text-muted-foreground">{lpo.supplierName}</p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleDownloadPDF}
              disabled={isDownloadingPDF}
              variant="outline"
            >
              <Download className="mr-2 h-4 w-4" />
              {isDownloadingPDF ? "Downloading..." : "Download PDF"}
            </Button>
            <Button onClick={() => setLocation("/dashboard")} variant="outline">
              Back
            </Button>
          </div>
        </div>

        {/* LPO Details */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>LPO Information</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-muted-foreground">Supplier</p>
              <p className="font-medium">{lpo.supplierName}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Delivery To</p>
              <p className="font-medium">{lpo.deliveryTo}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Delivery Date</p>
              <p className="font-medium">{new Date(lpo.deliveryDate).toLocaleDateString()}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Grand Total</p>
              <p className="font-medium text-lg">{lpo.grandTotal.toLocaleString()}</p>
            </div>
            {lpo.tenderRefNo && (
              <div>
                <p className="text-sm text-muted-foreground">Tender Ref. No.</p>
                <p className="font-medium">{lpo.tenderRefNo}</p>
              </div>
            )}
            {lpo.quotationRefNo && (
              <div>
                <p className="text-sm text-muted-foreground">Quotation Ref. No.</p>
                <p className="font-medium">{lpo.quotationRefNo}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Line Items */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Line Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Item No.</th>
                    <th className="text-left py-3 px-4">Description</th>
                    <th className="text-right py-3 px-4">Unit Price</th>
                    <th className="text-right py-3 px-4">Quantity</th>
                    <th className="text-right py-3 px-4">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => (
                    <tr key={item.id} className="border-b">
                      <td className="py-3 px-4">{item.itemNo}</td>
                      <td className="py-3 px-4">{item.description}</td>
                      <td className="py-3 px-4 text-right">{item.unitPrice.toLocaleString()}</td>
                      <td className="py-3 px-4 text-right">{item.quantity}</td>
                      <td className="py-3 px-4 text-right font-medium">{item.total.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Status Update */}
        <Card>
          <CardHeader>
            <CardTitle>Update Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">Status</label>
              <select
                value={status || lpo.status}
                onChange={(e) => setStatus(e.target.value)}
                className="w-full p-2 border rounded text-sm"
                disabled={isUpdating}
              >
                <option value="draft">Draft</option>
                <option value="submitted">Submitted</option>
                <option value="approved">Approved</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium">Notes</label>
              <textarea
                value={notes || lpo.notes || ""}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add notes (optional)"
                disabled={isUpdating}
                className="w-full p-2 border rounded text-sm"
                rows={3}
              />
            </div>
            <Button onClick={handleUpdateStatus} disabled={isUpdating} className="w-full">
              {isUpdating ? "Updating..." : "Update LPO"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
