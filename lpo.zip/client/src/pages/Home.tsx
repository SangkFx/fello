import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <div className="max-w-md text-center">
        <h1 className="text-4xl font-bold mb-4">LPO Manager</h1>
        <p className="text-lg text-muted-foreground mb-8">
          Manage Local Purchase Orders for your school with ease
        </p>
        
        {isAuthenticated ? (
          <Button 
            onClick={() => setLocation("/dashboard")}
            className="w-full"
            size="lg"
          >
            Go to Dashboard
          </Button>
        ) : (
          <div className="space-y-3">
            <Button 
              onClick={() => setLocation("/login")}
              className="w-full"
              size="lg"
            >
              Sign In
            </Button>
            <Button 
              onClick={() => setLocation("/register")}
              variant="outline"
              className="w-full"
              size="lg"
            >
              Create Account
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
